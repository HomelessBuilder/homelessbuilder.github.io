#!/bin/bash
# Meta-System 3.7 installer (test build).
#
# Run from inside the unpacked package folder, as your normal user (not
# root). It uses sudo for the system parts: installing packages and
# creating the `metasys` account. Everything Meta-System stores lives in
# that account's home folder, so uninstall.sh removes it completely.
#
# Automates the same steps as INSTALL-3.7-TEST.md, in the same order, each
# with its check. Works on Debian/Ubuntu and on Ubuntu under WSL2. The one step it can't do for you is the Claude login
# (step 4): it opens Claude Code for you to log in with your own account.
#
# Safe to re-run after a failure: finished steps are detected and skipped.
set -euo pipefail

MS_USER=metasys
PORT=8791
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say()  { printf '\n\033[1m== %s\033[0m\n' "$*"; }
ok()   { printf '   ok: %s\n' "$*"; }
fail() { printf '\n\033[31mSTOPPED:\033[0m %s\n' "$*" >&2
         printf 'Nothing is broken; fix the above and run ./install.sh again.\n' >&2
         printf 'If you are testing, send a screenshot of this screen.\n' >&2
         exit 1; }
# Run a command as the metasys user, in its home folder, with Claude
# Code's install folder on PATH. HOME is set through `env` rather than
# `sudo -H`: Ubuntu 26.04's sudo (sudo-rs) has no -H option.
as_ms() {
  sudo -u "$MS_USER" env HOME="$(getent passwd "$MS_USER" | cut -d: -f6)" \
    bash -c 'cd ~ && export PATH="$HOME/.local/bin:$PATH" && '"$1"
}

# ---- preflight ----
say "Checking this computer"
[ "$(id -u)" -ne 0 ] || fail "Run this as your normal user, not as root (it asks for sudo itself)."
grep -qiE '^(ID|ID_LIKE)=.*(debian|ubuntu)' /etc/os-release 2>/dev/null \
  || fail "This installer is for Debian or Ubuntu Linux. Other systems haven't been tried yet."
ok "Debian/Ubuntu"
# WSL2 (Ubuntu inside Windows) works, with two differences handled below:
# cron only runs if systemd does, and the browser is on the Windows side.
IS_WSL=0
grep -qiE 'microsoft|wsl' /proc/sys/kernel/osrelease 2>/dev/null && IS_WSL=1
HAS_SYSTEMD=0
[ "$(ps -p 1 -o comm= 2>/dev/null)" = "systemd" ] && HAS_SYSTEMD=1
[ "$IS_WSL" = 1 ] && ok "running in WSL (Ubuntu inside Windows)"
( cd "$HERE" && sha256sum --quiet -c SHA256SUMS ) \
  || fail "The package files don't match their checksums. Download it again."
ok "package files intact"
sudo -v || fail "This needs sudo (admin) rights for steps 1 and 2."
ok "sudo"

# ---- step 1 ----
say "Step 1 of 7: installing prerequisites"
sudo apt-get update -qq
sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq git tmux python3 python3-websockets curl cron >/dev/null
python3 -c 'import websockets' 2>/dev/null || fail "python3-websockets didn't install."
# 10 or newer: tested on 10.4 (Debian 12, Ubuntu 24.04) and 15.0.1 (Ubuntu
# 26.04). Ubuntu 22.04 ships 9.1, which hasn't been tried.
python3 -c 'import sys, websockets; sys.exit(int(websockets.__version__.split(".")[0]) < 10)' \
  || fail "This system's python3-websockets is older than version 10. Use Ubuntu 24.04 or newer."
command -v tmux >/dev/null || fail "tmux didn't install."
ok "git, tmux, python3, websockets, curl, cron"

# ---- step 2 ----
say "Step 2 of 7: creating the '$MS_USER' account"
if id "$MS_USER" >/dev/null 2>&1; then
  ok "'$MS_USER' already exists, using it"
else
  # No password: you reach this account with `sudo -iu metasys`, never by
  # logging in to it directly. Not in the sudo group; it needs no admin rights.
  sudo useradd -m -s /bin/bash "$MS_USER"
  ok "created '$MS_USER'"
fi
MS_HOME="$(getent passwd "$MS_USER" | cut -d: -f6)"
[ -d "$MS_HOME" ] || fail "'$MS_USER' has no home folder at $MS_HOME."
# useradd leaves the home folder readable by every account on the computer
# (Debian 12 does), and server.log in there holds the interface token, the
# password to terminals running as this account. Lock it to its owner.
sudo chmod 700 "$MS_HOME"
[ "$(stat -c %a "$MS_HOME")" = "700" ] || fail "Couldn't make $MS_HOME private."
ok "home folder private to '$MS_USER'"

# ---- step 3 ----
say "Step 3 of 7: putting the code and starting files in place"
if sudo test -d "$MS_HOME/meta-system-3-0"; then
  ok "code already in place, leaving it as is"
else
  # Your own home folder usually isn't readable by other accounts, so the
  # package files are copied somewhere metasys can read them first.
  STAGE="$MS_HOME/.ms37-handover"
  sudo install -d -o "$MS_USER" -g "$MS_USER" -m 700 "$STAGE"
  sudo install -o "$MS_USER" -g "$MS_USER" -m 644 \
    "$HERE"/meta-system-3-0.bundle "$HERE"/devlog-engine.bundle \
    "$HERE"/seed/CLAUDE.md "$HERE"/seed/DECISION-LOG.md "$HERE"/seed/IDEA-LOG.md "$STAGE"/
  as_ms '
    git clone -q -b ms3.7 .ms37-handover/meta-system-3-0.bundle meta-system-3-0 &&
    git clone -q -b ms3.7 .ms37-handover/devlog-engine.bundle devlog-engine &&
    cp -n .ms37-handover/CLAUDE.md .ms37-handover/DECISION-LOG.md ~/ &&
    mkdir -p idea-bank && cp -n .ms37-handover/IDEA-LOG.md idea-bank/ &&
    rm -rf .ms37-handover'
fi
for f in CLAUDE.md DECISION-LOG.md idea-bank/IDEA-LOG.md meta-system-3-0/app/start.sh devlog-engine/devlog; do
  sudo test -e "$MS_HOME/$f" || fail "$MS_HOME/$f is missing after step 3."
done
ok "code and starting files in $MS_HOME"

# ---- step 4 ----
say "Step 4 of 7: Claude Code"
if as_ms 'command -v claude' >/dev/null 2>&1; then
  ok "Claude Code already installed"
else
  as_ms 'curl -fsSL https://claude.ai/install.sh | bash' || fail "Claude Code's installer failed."
fi
as_ms 'grep -q "\.local/bin" ~/.bashrc || echo '\''export PATH="$HOME/.local/bin:$PATH"'\'' >> ~/.bashrc'
as_ms 'claude --version' >/dev/null || fail "Claude Code installed, but 'claude --version' doesn't run."
ok "Claude Code $(as_ms 'claude --version' | head -1)"

logged_in() { sudo test -s "$MS_HOME/.claude/.credentials.json"; }
if logged_in; then
  ok "already logged in"
else
  cat <<'MSG'

   Claude Code opens next. Log in with YOUR OWN Claude account and follow
   its prompts. If it shows a link instead of opening a browser, copy the
   link into your browser, log in there, and paste the code it gives you
   back here. When you see Claude Code's input box, type  /exit  and
   press Enter to come back here.

MSG
  read -r -p "   Press Enter to open Claude Code... " _
  as_ms 'claude' </dev/tty || true
  logged_in || fail "Claude Code isn't logged in yet. Run ./install.sh again to retry the login."
  ok "logged in"
fi

# ---- step 5 ----
say "Step 5 of 7: creating the database"
if sudo test -e "$MS_HOME/devlog-engine/devlog.db"; then
  ok "database already exists"
else
  as_ms 'cd devlog-engine && python3 -m devlog init >/dev/null && python3 -m devlog decisions-flip >/dev/null' \
    || fail "Creating the database failed."
fi
n="$(as_ms 'cd devlog-engine && python3 -m devlog --json decisions' | python3 -c 'import json,sys; d=json.load(sys.stdin); print(len(d if isinstance(d,list) else d.get("decisions",[])))')"
[ "$n" -ge 1 ] || fail "The decision log should have its starting entry but has $n."
ok "database ready ($n decision)"

# ---- step 6 ----
say "Step 6 of 7: starting Meta-System"
if ! as_ms 'cd meta-system-3-0/app && [ -f server.pid ] && kill -0 "$(cat server.pid)" 2>/dev/null'; then
  as_ms 'cd meta-system-3-0/app && ./start.sh' >/dev/null || fail "The server didn't start. See $MS_HOME/meta-system-3-0/app/server.log"
fi
TOKEN="$(sudo cat "$MS_HOME/meta-system-3-0/app/server.token")"
URL="http://127.0.0.1:$PORT/?token=$TOKEN"
for _ in 1 2 3 4 5; do
  curl -fs -o /dev/null "$URL" && break
  sleep 1
done
curl -fs -o /dev/null "$URL" || fail "The server is running but the interface doesn't answer on port $PORT."
ok "interface answering on port $PORT"

# ---- step 7 ----
say "Step 7 of 7: starting it automatically after a restart"
CRON_LINE="@reboot $MS_HOME/meta-system-3-0/app/boot-start.sh"
if as_ms 'crontab -l 2>/dev/null' | grep -qF "$CRON_LINE"; then
  ok "already set"
else
  as_ms "(crontab -l 2>/dev/null; echo '$CRON_LINE') | crontab -"
  as_ms 'crontab -l' | grep -qF "$CRON_LINE" || fail "Couldn't add the restart entry."
  ok "set"
fi
AUTOSTART=1
if [ "$HAS_SYSTEMD" = 1 ]; then
  sudo systemctl enable --now cron >/dev/null 2>&1 || true
  systemctl is-active --quiet cron || AUTOSTART=0
else
  AUTOSTART=0
fi
if [ "$AUTOSTART" = 1 ]; then
  ok "cron is running, so Meta-System starts by itself after a restart"
else
  printf '   note: cron isn'\''t running here, so after a restart start it yourself with\n'
  printf '         %s/start-metasystem.sh\n' "$HERE"
fi

if [ "$IS_WSL" = 1 ]; then
  WHERE="in your Windows browser (Edge, Chrome, ...)"
  AFTER="Keep this Ubuntu window open while you use Meta-System. If the address
stops loading (for example after Windows restarts), open Ubuntu and run
   $HERE/start-metasystem.sh
It starts Meta-System again and prints the same address."
else
  WHERE="in your browser on this computer"
  AFTER="If the address ever stops loading, run
   $HERE/start-metasystem.sh
It starts Meta-System again and prints the same address."
fi

cat <<MSG

$(printf '\033[1m')Installed.$(printf '\033[0m')

Open this address $WHERE:

   $URL

The token in it is the password to the interface, so keep it private. It's
also saved in $MS_HOME/meta-system-3-0/app/server.token (sudo cat it).

The first time it opens, a Setup chat pane starts by itself and greets
you: that's the setup interview. Answer it at your own pace.

$AFTER
MSG
