#!/bin/bash
# Starts Meta-System 3.7 if it isn't running, then prints its address.
# For after a restart when nothing started it automatically (for example
# WSL without systemd). Run as your normal user; it asks for sudo.
set -uo pipefail
MS_USER=metasys
PORT=8791
id "$MS_USER" >/dev/null 2>&1 || { echo "Meta-System isn't installed here (no '$MS_USER' account). Run ./install.sh first." >&2; exit 1; }
MS_HOME="$(getent passwd "$MS_USER" | cut -d: -f6)"
# HOME through `env`, not `sudo -H`: sudo-rs (Ubuntu 26.04) has no -H.
as_ms() { sudo -u "$MS_USER" env HOME="$MS_HOME" bash -c 'cd ~ && export PATH="$HOME/.local/bin:$PATH" && '"$1"; }

if as_ms 'cd meta-system-3-0/app && [ -f server.pid ] && kill -0 "$(cat server.pid)" 2>/dev/null'; then
  echo "Meta-System is already running."
else
  as_ms 'cd meta-system-3-0/app && ./start.sh' >/dev/null \
    || { echo "It didn't start. See $MS_HOME/meta-system-3-0/app/server.log (sudo cat it)." >&2; exit 1; }
  echo "Started."
fi
echo "Open: http://127.0.0.1:$PORT/?token=$(sudo cat "$MS_HOME/meta-system-3-0/app/server.token")"
