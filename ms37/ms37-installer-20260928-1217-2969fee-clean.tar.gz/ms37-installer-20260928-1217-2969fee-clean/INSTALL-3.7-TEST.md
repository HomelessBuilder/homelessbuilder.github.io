# Meta-System 3.7 — Test Install Steps

*A test procedure for installing Meta-System 3.7 on your own computer,
not a finished installer. Steps 3–5 have been rehearsed on a scratch
install. Updated 2026-09-27.*

---

## Before you start

You'll need these first:

1. **Debian or Ubuntu Linux.** The steps below are for those, which is
   what 3.7 runs on today. macOS should be close (tmux from Homebrew, a
   different command for adding a user) but hasn't been tried. Windows
   needs WSL2 (Ubuntu inside Windows) and hasn't been tried either.
2. **The code and starting files**, from whoever gave you this install:
   - two bundle files, `meta-system-3-0.bundle` and `devlog-engine.bundle`
     (or read access to the two repositories instead)
   - `CLAUDE.md`: the starting rules file
   - `DECISION-LOG.md`: the starting decision log, with one entry,
     "This install starts with empty logs"
   - `IDEA-LOG.md`: an empty idea log (optional; step 3 creates one if
     it's missing)
3. **Your own Claude subscription.** The chat panes and the setup
   interview run on your Claude Code login.
4. **Admin (`sudo`) rights** on the computer, for steps 1 and 2 only.

---

## Install steps

You'll set this up under a separate user account on your computer, named
`metasys`. Everything Meta-System stores lives in that account's home
folder, so it stays apart from your own files and is easy to remove
completely afterwards.

Commands in grey boxes are typed into a terminal. Each step ends with a
check. If a check doesn't match, stop and send a screenshot. Don't try to
work around it: finding those spots is what this test is for.

### Step 1: Install the prerequisites (as your normal user)

```bash
sudo apt update
sudo apt install -y git tmux python3 python3-websockets curl cron
```

**Check:**
```bash
python3 -c 'import websockets; print(websockets.__version__)'
tmux -V
```
Both print a version number.

### Step 2: Create the `metasys` user

```bash
sudo adduser metasys
```
Choose a password and press Enter through the other questions. Don't add
this user to the `sudo` group; it doesn't need admin rights.

**Check:** `id metasys` prints a line with `uid=` in it.

### Step 3: Put the code and starting files in place

Copy the files you were given (two `.bundle` files, `CLAUDE.md`,
`DECISION-LOG.md`, and `IDEA-LOG.md` if you got one) into
`/tmp/ms37-handover`, then:

```bash
sudo chmod -R a+rX /tmp/ms37-handover
sudo -iu metasys
```
You're now working as `metasys`; the prompt changes. Then:

```bash
cd ~
git clone -b ms3.7 /tmp/ms37-handover/meta-system-3-0.bundle meta-system-3-0
git clone -b ms3.7 /tmp/ms37-handover/devlog-engine.bundle   devlog-engine
cp /tmp/ms37-handover/CLAUDE.md /tmp/ms37-handover/DECISION-LOG.md ~/
mkdir -p ~/idea-bank
if [ -f /tmp/ms37-handover/IDEA-LOG.md ]; then
  cp /tmp/ms37-handover/IDEA-LOG.md ~/idea-bank/
else
  printf '# Idea Log\n\n*Append-only. Newest entries at top.*\n\n---\n' > ~/idea-bank/IDEA-LOG.md
fi
```

**Check:** `ls ~` shows `CLAUDE.md  DECISION-LOG.md  devlog-engine  idea-bank  meta-system-3-0`.

*(If you were given repository access instead of bundles, clone with
`git clone -b ms3.7 <repo URL>` instead. Everything else is the same.)*

### Step 4: Install Claude Code and log in (still as `metasys`)

```bash
curl -fsSL https://claude.ai/install.sh | bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
claude
```
Follow the login prompts with your own Claude account. When Claude Code
is running, type `/exit`.

**Check:** `claude --version` prints a version number.

### Step 5: Create the database (still as `metasys`)

```bash
cd ~/devlog-engine
python3 -m devlog init
python3 -m devlog decisions-flip
```
The first command creates the database. The second makes it the master
copy of the decision log. After that, `DECISION-LOG.md` is regenerated
from the database, so never edit it by hand.

**Check:**
```bash
python3 -m devlog --json decisions
```
Prints one entry titled "This install starts with empty logs."

### Step 6: Start Meta-System (still as `metasys`)

```bash
cd ~/meta-system-3-0/app
./start.sh
```
It prints a line starting `Open: http://127.0.0.1:8791/?token=...`.
Copy that whole address and save it somewhere private: **the token in it
is the password to the interface.** You can find it again later in
`~/meta-system-3-0/app/server.token`.

**Check:** open the address in your normal browser on this computer. The
Meta-System interface loads, and because this is the first time it has
opened, a **Setup** chat pane opens by itself and greets you. That's the
setup interview. You can start answering now, or leave it and come back
to it in Step 8; it keeps its place across restarts.

### Step 7: Start it automatically after a restart (still as `metasys`)

```bash
(crontab -l 2>/dev/null; echo "@reboot $HOME/meta-system-3-0/app/boot-start.sh") | crontab -
```

**Check:** restart the computer, wait a minute after logging in, and open
the saved address again. It loads with the same layout. Any terminal
panes you had open come back.

### Step 8: Run the setup interview

This is the guided first-run setup. It asks about you and your work in
plain language, then builds your starting system: a profile of you, your
projects, and your first decisions and ideas. It started by itself the
first time you opened the interface (Step 6):

1. Find the **Chat · setup** pane. It has already greeted you and
   offered two paces: step by step, or "just tell me about yourself."
2. Answer its questions until it says setup is done.

If you closed that pane, open it again from the **＋ persona** dropdown
at the top: choose **Setup**, then type any message, such as `hi`, and
press Enter.

Setup may ask you to run a command yourself now and then. It's only
allowed to run its own database commands, so anything else goes through
you.

**Check:** open **Decision Log** and **Idea Bank**. Each now shows what
the interview added alongside the starting entry. Also check that
`~/ABOUT-ME.md` exists:
```bash
ls ~/ABOUT-ME.md
```

### Step 9: Try it and write down what happens

This is the actual test. For each item, note what worked, what showed an
error, and what just looked empty:

- **Every pane.** Which load with content, which load empty, and which
  show an error. Some panes were built for tools that aren't part of
  this install, and knowing which ones is the point.
- **A terminal pane.** Does it open, and can you type in it?
- **A chat pane.** Does Claude answer a message?
- **Decision Log → New.** Add a test decision. Does it appear in the list?
- **Idea Bank.** Add a test idea. Does it appear?
- **Anything that mentions a person, path or project that isn't yours.**
  3.7 is meant to start with no one else's identity or history in it,
  so every one of these is a bug worth reporting.

---

## Known before you start

- **The setup interview starts by itself, once.** The first time the
  interface opens, it opens a Setup pane and sends the first message for
  you (Steps 6 and 8). It has been tested end to end on a scratch
  install by a script, but no person has run it yet. Your run is the first, so note anything
  that feels confusing, not just errors.
- **Idea Bank → devlog.** Ideas stay in `~/idea-bank/IDEA-LOG.md` as the
  master copy. That's intended.
- **Older design documents.** The code folder still carries design notes
  and handoff documents from the system's earlier development. The
  software runs without them, and they can mention people, paths and
  projects that aren't part of your install. They're the known
  exception to the last item in Step 9.

## Removing it completely

As your normal user:
```bash
sudo crontab -r -u metasys
sudo pkill -u metasys
sudo deluser --remove-home metasys
```
That removes the account, everything Meta-System stored, and the
autostart entry. Step 1's packages (git, tmux, and so on) stay installed.
