# Meta-System 3.7: evaluation install

This package installs Meta-System 3.7 on your own computer so you can try
it. It's an early build, and you're one of the first people to install
it. Anything that confuses you or goes wrong is useful to write down,
along with what worked.

## What you need

- **Windows 10 or 11 with WSL2** (Ubuntu running inside Windows), or an
  Ubuntu or Debian Linux computer or virtual machine. Use Ubuntu 24.04 or
  newer.
- **Admin rights** on the computer.
- **Your own Claude subscription.** Meta-System's chat runs on your
  Claude login.
- About 15 minutes.

## On Windows: set up Ubuntu first

Skip this part if you're already on Linux.

1. Open **PowerShell as administrator** (right-click the Start button,
   choose "Terminal (Admin)" or "PowerShell (Admin)"), and run:
   ```
   wsl --install -d Ubuntu
   ```
   Restart Windows if it asks you to.
2. Open **Ubuntu** from the Start menu. The first time, it asks you to
   choose a username and password. This password is the one the
   installer asks for later.
3. Download the installer file (`ms37-installer-….tar.gz`) in your
   browser. It lands in your Windows Downloads folder.

Everything from here on is typed into the Ubuntu window.

## Install

Copy the installer into Ubuntu and unpack it. On Windows, replace
`YOUR-WINDOWS-NAME` with your Windows user folder's name:

```bash
cp /mnt/c/Users/YOUR-WINDOWS-NAME/Downloads/ms37-installer-*.tar.gz ~/
cd ~ && tar xzf ms37-installer-*.tar.gz && cd ms37-installer-*/
./install.sh
```

On Linux, skip the `cp` line and run the rest from wherever you
downloaded the file.

The installer runs seven steps and checks each one as it goes:

1. It asks for your password (the Ubuntu one on Windows).
2. Partway through, it pauses so you can log in to Claude Code with your
   own Claude account. It prints the exact commands to type:
   ```bash
   sudo -iu metasys
   claude
   ```
   Log in, and if a browser doesn't open, copy the link it shows into
   your browser, log in, and paste the code back. Type `/exit` to leave
   Claude Code, then `exit`, then run `./install.sh` again. It skips
   what's already done and finishes the install.
3. At the end it prints an address starting `http://127.0.0.1:8791/`.
   Open it in your browser (on Windows, your normal Windows browser).

The first time the address opens, a **Setup** chat starts by itself and
says hello. That's the setup interview: it asks about you and your work,
then builds your starting system from your answers. Take your time with
it.

The token at the end of the address is the password to your
Meta-System, so keep it private.

If a step stops, it prints a red STOPPED message saying which step and
why. Take a screenshot, fix what it says if you can, and run
`./install.sh` again. It picks up where it stopped, including a step that
stopped halfway. If you'd rather start clean, run `./uninstall.sh` first.

## After a restart

On Linux, Meta-System starts by itself after a restart. On Windows,
open Ubuntu first, and keep its window open while you use Meta-System.
If the address doesn't load, run this in Ubuntu:

```bash
~/ms37-installer-*/start-metasystem.sh
```

It starts Meta-System again and prints the same address.

## What to try, and what to note

- **The setup interview.** Did it make sense? Where did it lose you?
- **Every pane.** Which show content, which are empty, and which show an
  error. Some panes were built for tools that aren't part of this
  install, and knowing which ones is part of the point.
- **A terminal pane.** Does it open, and can you type in it?
- **Decision Log and Idea Bank.** Add a test entry to each. Does it
  appear?
- **Anything mentioning a person, path or project that isn't yours.**
  The code still carries notes from its own development, so some of
  these are expected. They're still worth a note.

Send screenshots and notes to the person who gave you this installer.

## Remove it

```bash
~/ms37-installer-*/uninstall.sh
```

This deletes the `metasys` account the installer created and everything
Meta-System stored in it. On Windows you can also remove Ubuntu entirely
from Settings → Apps.

## What's in here

- `install.sh`, `uninstall.sh`, `start-metasystem.sh`: the scripts above.
- `meta-system-3-0.bundle`, `devlog-engine.bundle`: the code, as git
  bundles.
- `seed/`: the three starting files (instructions, decision log, idea
  log).
- `INSTALL-3.7-TEST.md`: the same install done by hand, step by step.
- `SHA256SUMS`: checksums the installer uses to confirm the download
  isn't damaged.
- `VERSION`: which build this is.
