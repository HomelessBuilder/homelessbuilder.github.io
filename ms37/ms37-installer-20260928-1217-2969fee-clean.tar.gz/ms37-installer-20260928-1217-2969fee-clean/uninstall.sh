#!/bin/bash
# Removes Meta-System 3.7 completely: the `metasys` account, everything it
# stored, and its restart entry. The prerequisite packages (git, tmux and
# so on) stay installed. Run as your normal user.
set -uo pipefail
MS_USER=metasys

id "$MS_USER" >/dev/null 2>&1 || { echo "No '$MS_USER' account here; nothing to remove."; exit 0; }
MS_HOME="$(getent passwd "$MS_USER" | cut -d: -f6)"

cat <<MSG
This permanently deletes the '$MS_USER' account and everything in
$MS_HOME: your setup, decision log, ideas, and chat history.
MSG
read -r -p "Type 'remove' to go ahead: " answer
[ "$answer" = "remove" ] || { echo "Nothing removed."; exit 0; }

sudo crontab -r -u "$MS_USER" 2>/dev/null
sudo pkill -u "$MS_USER"
sleep 2
sudo pkill -9 -u "$MS_USER" 2>/dev/null
sudo userdel -r "$MS_USER" 2>/dev/null
if id "$MS_USER" >/dev/null 2>&1 || [ -d "$MS_HOME" ]; then
  echo "Something is left over: check 'id $MS_USER' and $MS_HOME." >&2
  exit 1
fi
echo "Removed."
