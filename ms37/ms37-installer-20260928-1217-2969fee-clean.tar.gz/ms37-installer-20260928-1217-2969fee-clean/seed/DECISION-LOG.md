# Decision Log

Decisions for this install, each recorded with its expected outcome and later reviewed against what actually happened. `devlog.db` is master: add or change entries with `devlog decision-add` / `devlog decision-edit` (or the Decision Log pane). This file is regenerated from those writes, so don't hand-edit it.

**Format:** newest at top. Each entry: Decision / Reasoning / Assumptions / Expected outcome / Review trigger / Status / Results.

---

## DEC-001 — This install starts with empty logs (decided 2026-09-21)

- **Decision:** The decision log, idea bank and instructions start empty. Nothing is copied from the install this one was derived from.
- **Reasoning:** This install follows the Meta-System's working pattern without being tied to any one person's identity and history, so it can serve other purposes.
- **Assumptions:** The pattern works without inherited history; what's needed gets rebuilt here through use.
- **Expected outcome:** Everything recorded here was decided on this install.
- **Review trigger:** Before this install is used for real work or offered to anyone else.
- **Status:** Decided
- **Results:** —
