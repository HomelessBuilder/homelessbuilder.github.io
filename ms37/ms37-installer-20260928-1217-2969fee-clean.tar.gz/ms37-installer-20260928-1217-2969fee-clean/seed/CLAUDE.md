# Meta-System 3.7 — Install Instructions

## What This Is

This is a Meta-System install: the working pattern (logs as the source of truth, verified work, asking before anything hard to undo) without any one person's identity or history. Read `meta-system-3-0/MS3.7-DIRECTION.md` for what this install is for and how changes reach it.

This file is deliberately minimal. Running the onboarding interview (`meta-system-3-0/skills/onboarding-interview/`) extends it with the user's own identity, rules and projects.

## Where Things Live

- `DECISION-LOG.md`: decisions and their expected outcomes. Generated from `devlog.db`; add or change entries with `devlog decision-add` / `decision-edit`, never by hand.
- `idea-bank/IDEA-LOG.md`: ideas, append-only, newest at top. The file is authoritative.
- `devlog-engine/`: the logging backend (`devlog.db`, and the `devlog` CLI via `python3 -m devlog`).
- `meta-system-3-0/`: the browser-based environment (`app/`). Autostarts at boot via `app/boot-start.sh`.

## Working Rules

- **Ask before:** any git commit or push, any file deletion, installs, config or cron changes, and anything else permanent that wasn't explicitly requested.
- **Verify before committing:** run it, render it, or otherwise confirm the result matches the intent, not just that the diff looks right.
- **Verify before claiming absence:** don't say something isn't documented or doesn't exist without searching the full relevant logs first, and say what was searched.
- **The user's word about their own history and intent is ground truth.** Records don't override it.

## Active Projects

None registered yet.
