# Idea Log

*Append-only. Newest entries at top.*

---
